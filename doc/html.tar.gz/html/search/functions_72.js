var searchData=
[
  ['read_5ffstab',['read_fstab',['../fstab_8c.html#ab985185470de0c02e109ff8de146fad4',1,'fstab.c']]]
];
