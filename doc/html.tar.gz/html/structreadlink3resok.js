var structreadlink3resok =
[
    [ "symlink_attributes", "structreadlink3resok.html#aa3fd9d9487d27d946dbf16409a18c00f", null ],
    [ "data", "structreadlink3resok.html#a570ac32fb52effb613d82b22cf82cfd6", null ]
];