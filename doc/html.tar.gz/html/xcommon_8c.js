var xcommon_8c =
[
    [ "xstrndup", "xcommon_8c.html#ae2eb416cff19e5aaa7be256d27fb6d77", null ],
    [ "xstrconcat2", "xcommon_8c.html#a1c2faee531a084da9dbd9e2155f86ec2", null ],
    [ "xstrconcat3", "xcommon_8c.html#aa8b66e9e97b7310f81ddc2bcd66acc33", null ],
    [ "xstrconcat4", "xcommon_8c.html#abb149ed1a6b979cde7bf4b288a9c1633", null ],
    [ "nfs_error", "xcommon_8c.html#ad3b60fb16a728e8734d256cadbe2f308", null ],
    [ "canonicalize", "xcommon_8c.html#a3af2cd82f0514540487bcdb54b9a355d", null ],
    [ "die", "xcommon_8c.html#a9c7dab7e21aad8e4f343ba73120e245b", null ],
    [ "die_if_null", "xcommon_8c.html#a4a7282308954c181993cbb5c1591381a", null ],
    [ "xmalloc", "xcommon_8c.html#a42ccfa6fc49cc4ce90cc44cd05052490", null ],
    [ "xrealloc", "xcommon_8c.html#a9f6bc6d637434a7cca469629ed0594ed", null ],
    [ "xfree", "xcommon_8c.html#a976e14808b9247ec952c262553f09f8f", null ],
    [ "xstrdup", "xcommon_8c.html#a31c8e4cd784d16e28687ee2f10b80028", null ],
    [ "at_die", "xcommon_8c.html#a115ce574fe5cca364afa17c11067cb66", null ]
];