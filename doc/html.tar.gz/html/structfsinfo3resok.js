var structfsinfo3resok =
[
    [ "obj_attributes", "structfsinfo3resok.html#ad21f408dd63203c64171a2c7a1e5d3ea", null ],
    [ "rtmax", "structfsinfo3resok.html#a2daa95d98affd01ee9732dec9f40676a", null ],
    [ "rtpref", "structfsinfo3resok.html#a7f656dd36f8fcbc4419d167884efdc8c", null ],
    [ "rtmult", "structfsinfo3resok.html#a8f11870be13ac631579c1c37117de740", null ],
    [ "wtmax", "structfsinfo3resok.html#a6ae9a72c3b2312e1e48be28d3b3aa0ac", null ],
    [ "wtpref", "structfsinfo3resok.html#a182cab3330f0096d73bdfd9f8f70f86f", null ],
    [ "wtmult", "structfsinfo3resok.html#aa3c3de2787191a2faeea1bba975f1e49", null ],
    [ "dtpref", "structfsinfo3resok.html#a79681be4dd63e6103a69dd54dd9e96b7", null ],
    [ "maxfilesize", "structfsinfo3resok.html#a4fd7712361145749d0939aadf06ff86d", null ],
    [ "time_delta", "structfsinfo3resok.html#add92303b774f7dacc543e5cfd2a8aa4d", null ],
    [ "properties", "structfsinfo3resok.html#a372acf76c341ab496e8e1f9e630e4601", null ]
];