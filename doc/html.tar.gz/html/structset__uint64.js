var structset__uint64 =
[
    [ "set", "structset__uint64.html#ac829eda4b0a8e534696efb9800d12c8e", null ],
    [ "val", "structset__uint64.html#a455b3605dc605fe8e055b9c1470535cf", null ],
    [ "set_uint64_u", "structset__uint64.html#a364a0891a21d209c247e6374a9cb4750", null ]
];