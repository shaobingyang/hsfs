var structrename3res =
[
    [ "status", "structrename3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "res", "structrename3res.html#a8f3c75236d025b1589b500a1bc512e55", null ],
    [ "rename3res_u", "structrename3res.html#acf23cb38ff9c1364ac6814bd9caca7aa", null ]
];