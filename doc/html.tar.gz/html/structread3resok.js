var structread3resok =
[
    [ "file_attributes", "structread3resok.html#acef4df54559fdc6312675454e066c5f0", null ],
    [ "count", "structread3resok.html#a383305f01908a8a9690580b9d89783a8", null ],
    [ "eof", "structread3resok.html#a93e57e22ecb79a9a76ba719ca67f1d38", null ],
    [ "data_len", "structread3resok.html#a6229279728b6dcb4e6fb8e61c05ecae9", null ],
    [ "data_val", "structread3resok.html#abc33c405605e58fccb47d4b655c81de2", null ],
    [ "data", "structread3resok.html#a1b73a62fca384b18dd829224296db1de", null ]
];