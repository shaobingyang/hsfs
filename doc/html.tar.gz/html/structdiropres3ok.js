var structdiropres3ok =
[
    [ "obj", "structdiropres3ok.html#ad94b6fca63d96a70e8f3e10dac103851", null ],
    [ "obj_attributes", "structdiropres3ok.html#ad21f408dd63203c64171a2c7a1e5d3ea", null ],
    [ "dir_wcc", "structdiropres3ok.html#a882fedaa970a7c3ef4580ecc049f6f78", null ]
];