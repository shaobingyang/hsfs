var structcommit3resok =
[
    [ "file_wcc", "structcommit3resok.html#a336757df8db9bf8e8bf6696166765dad", null ],
    [ "verf", "structcommit3resok.html#a9adf8cec7f9fe03b00328bbeee95ea1f", null ]
];