var searchData=
[
  ['bindtextdomain',['bindtextdomain',['../nls_8h.html#add6dfc1077058ff26d79cdb18099d58a',1,'nls.h']]]
];
