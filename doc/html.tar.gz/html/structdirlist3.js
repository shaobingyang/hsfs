var structdirlist3 =
[
    [ "entries", "structdirlist3.html#ac067d538d22621bbbfb155c26e45bc6e", null ],
    [ "eof", "structdirlist3.html#a93e57e22ecb79a9a76ba719ca67f1d38", null ]
];