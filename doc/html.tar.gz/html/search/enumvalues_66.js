var searchData=
[
  ['file_5fsync',['FILE_SYNC',['../nfs3_8h.html#a60d7dfa09d8ec7201b6d7b11420f8978a02ddca92e0a50885f7a30b97abccc95f',1,'nfs3.h']]]
];
