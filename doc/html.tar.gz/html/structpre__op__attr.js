var structpre__op__attr =
[
    [ "present", "structpre__op__attr.html#a8e398d9a28a80055b9f3408408a85cf6", null ],
    [ "attributes", "structpre__op__attr.html#adb72d91119fa160efe5168419807b02e", null ],
    [ "pre_op_attr_u", "structpre__op__attr.html#a429a4dc833220f6f78c2f6e6fb289764", null ]
];