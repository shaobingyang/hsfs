var structreaddir3resok =
[
    [ "dir_attributes", "structreaddir3resok.html#a6c1ae7519ea651b1784da5df16159fcd", null ],
    [ "cookieverf", "structreaddir3resok.html#aae8af4f9de9dc26c29fba890972706c0", null ],
    [ "reply", "structreaddir3resok.html#a6f93ba425d93e6ab600291840b17ae35", null ]
];