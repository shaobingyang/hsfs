var structrename3wcc =
[
    [ "fromdir_wcc", "structrename3wcc.html#a25fc790f61fa97a35dcde261ca542ccd", null ],
    [ "todir_wcc", "structrename3wcc.html#ac80240b30746d49e2889a73221f04391", null ]
];