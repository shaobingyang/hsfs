var struct_g_e_t_a_c_l3resok =
[
    [ "attr", "struct_g_e_t_a_c_l3resok.html#a404c8762420ae23a423c9612ef2970ba", null ],
    [ "acl", "struct_g_e_t_a_c_l3resok.html#ad411d2b1744da8e8231d523d7be15f73", null ]
];