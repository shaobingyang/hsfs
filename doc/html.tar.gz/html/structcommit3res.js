var structcommit3res =
[
    [ "status", "structcommit3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "resok", "structcommit3res.html#a882b99a04a695c255443d9de28ce7344", null ],
    [ "resfail", "structcommit3res.html#aad5a4593dd16c182ff4b3f74118f6db2", null ],
    [ "commit3res_u", "structcommit3res.html#a8f6c637be2dfeab1d55e5e3597a02d03", null ]
];