var structposix__acl__xattr__entry =
[
    [ "e_tag", "structposix__acl__xattr__entry.html#a3b91aa5bd504afcf919ca6492679a501", null ],
    [ "e_perm", "structposix__acl__xattr__entry.html#afab82b556f02c8823990bf8155143af0", null ],
    [ "e_id", "structposix__acl__xattr__entry.html#a65bcaadcc1939e9491d48782bf971a2b", null ]
];