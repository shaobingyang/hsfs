var structwrite3res =
[
    [ "status", "structwrite3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "resok", "structwrite3res.html#a42f203eb2d5561ca905e2dde7a01a53b", null ],
    [ "resfail", "structwrite3res.html#aad5a4593dd16c182ff4b3f74118f6db2", null ],
    [ "write3res_u", "structwrite3res.html#ab39ce2c6030f0e1db3ac626d60c9c33f", null ]
];