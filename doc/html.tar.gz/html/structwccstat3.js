var structwccstat3 =
[
    [ "status", "structwccstat3.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "wcc", "structwccstat3.html#acdcc5e037af33b3584326bc911f16b25", null ],
    [ "wccstat3_u", "structwccstat3.html#ae0b6630289d70b0309679d7cf71a3f7b", null ]
];