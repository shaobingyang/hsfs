var searchData=
[
  ['data_5fsync',['DATA_SYNC',['../nfs3_8h.html#a60d7dfa09d8ec7201b6d7b11420f8978a5b1f3779dbd0aa31b32ffd1779536c81',1,'nfs3.h']]],
  ['dont_5fchange',['DONT_CHANGE',['../nfs3_8h.html#a073a77f0e47a0652458d490f531e0c6da0112ffba4da19444de62dd0ec75654c6',1,'nfs3.h']]]
];
