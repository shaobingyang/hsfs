var structnfs__mntent__s =
[
    [ "mnt_fsname", "structnfs__mntent__s.html#a3f52d79e8a990c28d378e363174d59bf", null ],
    [ "mnt_dir", "structnfs__mntent__s.html#a98c78f3d55b8852a62270b6ee0cf6807", null ],
    [ "mnt_type", "structnfs__mntent__s.html#a339a5583c28525583b5c16f436493e4a", null ],
    [ "mnt_opts", "structnfs__mntent__s.html#a929087e76ef76b528b05984eb5cbf12b", null ],
    [ "mnt_freq", "structnfs__mntent__s.html#a5176b1fc6e17d15e11dbac5179bfc23d", null ],
    [ "mnt_passno", "structnfs__mntent__s.html#a2f19282da2e28d80b97057954e890679", null ]
];