var structhsfs__inode =
[
    [ "ino", "structhsfs__inode.html#abe4f1d2e45f8a6e0fbd72a5c7953e24c", null ],
    [ "generation", "structhsfs__inode.html#af121146f9ac963802e779806fa004129", null ],
    [ "fh", "structhsfs__inode.html#af9c0376501fe3e2532086f32ce43d6bb", null ],
    [ "nlookup", "structhsfs__inode.html#a2de36b0174737559bdb8e24b8ff1f3ee", null ],
    [ "attr", "structhsfs__inode.html#aab0bd7e8e31f6c6c957b4a5e48822f67", null ],
    [ "sb", "structhsfs__inode.html#aecf8c299974388c69f7c47bc2c923c84", null ],
    [ "next", "structhsfs__inode.html#ac53e1e348ff9aacb75f4f5f97a374dbe", null ]
];