var structwcc__data =
[
    [ "before", "structwcc__data.html#a04b6a3a55c2f51e4aaf9fc0b48d273ec", null ],
    [ "after", "structwcc__data.html#aff23383e9d6ddec13e9dd3ee11391f3b", null ]
];