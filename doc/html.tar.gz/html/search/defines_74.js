var searchData=
[
  ['textdomain',['textdomain',['../nls_8h.html#a3adff4c69f0a5613a459ff23d749166c',1,'nls.h']]]
];
