var searchData=
[
  ['uid',['uid',['../structhsfs__sattr.html#a1163f413982fef86f5c8313564d8589c',1,'hsfs_sattr::uid()'],['../structfattr3.html#a8b60f54cc01afb76c0a10520e844698f',1,'fattr3::uid()'],['../structsattr3.html#a4bc450723c9de2fdb5dbdbe4dad45ff2',1,'sattr3::uid()'],['../acl3_8h.html#ac83b9ada9e7333675745ef795a057883',1,'uid():&#160;acl3.h']]],
  ['umntarg_5ft',['umntarg_t',['../hsi__nfs3__mount_8c.html#ae57a4d1d5fd96236625d4e274a91dac0',1,'hsi_nfs3_mount.c']]],
  ['unchecked',['UNCHECKED',['../nfs3_8h.html#adc37f68185850e518e76a8ace956946fac09241148cb51bc72137fbe835df8986',1,'nfs3.h']]],
  ['unlikely',['unlikely',['../log_8h.html#ac6c45889010c1bd68631771b64f18101',1,'log.h']]],
  ['unlock_5fmtab',['unlock_mtab',['../fstab_8h.html#a7ce6803a0833d2c6161b7abbb2d2b8dc',1,'unlock_mtab(void):&#160;fstab.c'],['../fstab_8c.html#a7ce6803a0833d2c6161b7abbb2d2b8dc',1,'unlock_mtab(void):&#160;fstab.c']]],
  ['unstable',['UNSTABLE',['../nfs3_8h.html#a60d7dfa09d8ec7201b6d7b11420f8978a6059c695546caa6887fe521f96fe149e',1,'nfs3.h']]],
  ['update_5fmtab',['update_mtab',['../fstab_8h.html#a20b0a60ab923ca78d6209541972f4f56',1,'update_mtab(const char *special, nfs_mntent_t *with):&#160;fstab.c'],['../fstab_8c.html#aaa6339edb309a742bcae900bf5fdec4b',1,'update_mtab(const char *dir, nfs_mntent_t *instead):&#160;fstab.c']]],
  ['use',['use',['../structhsfs__table.html#aa4fc36834fb46d7d31820ed6c7bbd38d',1,'hsfs_table']]],
  ['used',['used',['../structfattr3.html#a9c3d06d4885f0380ebbe940335ebb1d4',1,'fattr3']]]
];
