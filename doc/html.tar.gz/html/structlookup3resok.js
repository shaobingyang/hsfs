var structlookup3resok =
[
    [ "object", "structlookup3resok.html#a8d71a58741a7b7af2f6ae5c069326577", null ],
    [ "obj_attributes", "structlookup3resok.html#ad21f408dd63203c64171a2c7a1e5d3ea", null ],
    [ "dir_attributes", "structlookup3resok.html#a6c1ae7519ea651b1784da5df16159fcd", null ]
];