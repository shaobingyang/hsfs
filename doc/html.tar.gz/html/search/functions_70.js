var searchData=
[
  ['posix_5facl_5falloc',['posix_acl_alloc',['../acl_8h.html#a193444023d7075874db8f394febc3b0e',1,'posix_acl_alloc(int count):&#160;hsi_acl3.c'],['../hsi__acl3_8c.html#a193444023d7075874db8f394febc3b0e',1,'posix_acl_alloc(int count):&#160;hsi_acl3.c']]],
  ['posix_5facl_5ffrom_5fmode',['posix_acl_from_mode',['../acl_8h.html#a917a6538cb0776fb9ec8bd6e4cb81139',1,'posix_acl_from_mode(mode_t mode):&#160;hsi_acl3.c'],['../hsi__acl3_8c.html#a917a6538cb0776fb9ec8bd6e4cb81139',1,'posix_acl_from_mode(mode_t mode):&#160;hsi_acl3.c']]],
  ['posix_5facl_5ffrom_5fxattr',['posix_acl_from_xattr',['../acl_8h.html#a7b35954a8efa998046c171c3f6007618',1,'posix_acl_from_xattr(const void *value, size_t size):&#160;hsi_acl3.c'],['../hsi__acl3_8c.html#a7b35954a8efa998046c171c3f6007618',1,'posix_acl_from_xattr(const void *value, size_t size):&#160;hsi_acl3.c']]],
  ['posix_5facl_5fto_5fxattr',['posix_acl_to_xattr',['../acl_8h.html#a169574aaf4249ca59dccc2b8ae472011',1,'posix_acl_to_xattr(const struct posix_acl *acl, void *buffer, size_t size):&#160;hsi_acl3.c'],['../hsi__acl3_8c.html#a169574aaf4249ca59dccc2b8ae472011',1,'posix_acl_to_xattr(const struct posix_acl *acl, void *buffer, size_t size):&#160;hsi_acl3.c']]]
];
