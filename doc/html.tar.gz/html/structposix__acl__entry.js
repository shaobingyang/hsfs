var structposix__acl__entry =
[
    [ "e_tag", "structposix__acl__entry.html#acd536f2f9a40f14c213d8da60dba4d8c", null ],
    [ "e_perm", "structposix__acl__entry.html#a8c5c654624b03dc3654e7c91e9a498c3", null ],
    [ "e_id", "structposix__acl__entry.html#abc482427bc551be74713b64aff01eb20", null ]
];