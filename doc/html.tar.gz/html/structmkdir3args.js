var structmkdir3args =
[
    [ "where", "structmkdir3args.html#a199e09cf4dc3e9e01c3cf16dd71d7fc1", null ],
    [ "attributes", "structmkdir3args.html#a93a112077cda7b8c5d21a60a6dde2547", null ]
];