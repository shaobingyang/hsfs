var searchData=
[
  ['generation',['generation',['../structhsfs__inode.html#af121146f9ac963802e779806fa004129',1,'hsfs_inode']]],
  ['getacl3res_5fu',['GETACL3res_u',['../struct_g_e_t_a_c_l3res.html#a92eb06b89f84c00af7e2c55fca31e21d',1,'GETACL3res']]],
  ['getattr3res_5fu',['getattr3res_u',['../structgetattr3res.html#abb86e1e25d1143122ace38413bca2629',1,'getattr3res']]],
  ['getxattrdir3res_5fu',['GETXATTRDIR3res_u',['../struct_g_e_t_x_a_t_t_r_d_i_r3res.html#ae33ace39e8cedca57417fe889e2f3fc0',1,'GETXATTRDIR3res']]],
  ['gid',['gid',['../structhsfs__sattr.html#accbf90b0b518578acff258d328c5575d',1,'hsfs_sattr::gid()'],['../structfattr3.html#a3c86d591be7e5f55e5a99e8abe4e0fff',1,'fattr3::gid()'],['../structsattr3.html#a86f6461aa98b325464630da727b54b15',1,'sattr3::gid()']]],
  ['gr_5fname',['gr_name',['../structgroupnode.html#a44d1cf7d5f937e100fa3b112aaa86506',1,'groupnode']]],
  ['gr_5fnext',['gr_next',['../structgroupnode.html#a321b63335e032d992717aee96ed69ff2',1,'groupnode']]],
  ['guard',['guard',['../structsetattr3args.html#afbfc38e8ecb27b0942cc4174ffc7a7cc',1,'setattr3args']]]
];
