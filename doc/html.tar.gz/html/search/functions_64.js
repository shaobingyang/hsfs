var searchData=
[
  ['die',['die',['../xcommon_8c.html#a9c7dab7e21aad8e4f343ba73120e245b',1,'die(int err, const char *fmt,...):&#160;xcommon.c'],['../xcommon_8h.html#a0818e62af58745e448f1a0cdae328e1e',1,'die(int errcode, const char *fmt,...):&#160;xcommon.c']]]
];
