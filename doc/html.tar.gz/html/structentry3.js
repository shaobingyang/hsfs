var structentry3 =
[
    [ "fileid", "structentry3.html#ae056fb2f84ade36a5247f62d4e04137f", null ],
    [ "name", "structentry3.html#a067b2559647149ee0a8fd423d0d5564d", null ],
    [ "cookie", "structentry3.html#a3320022856a7759e1757a4ab48c9a380", null ],
    [ "nextentry", "structentry3.html#a31de779f318049c187c64dd5cec8b54b", null ]
];