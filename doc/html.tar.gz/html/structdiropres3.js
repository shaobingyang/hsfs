var structdiropres3 =
[
    [ "status", "structdiropres3.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "resok", "structdiropres3.html#a0f354e5f2b0ad631a2e868c2b7f0d533", null ],
    [ "resfail", "structdiropres3.html#aad5a4593dd16c182ff4b3f74118f6db2", null ],
    [ "diropres3_u", "structdiropres3.html#a207b67bb0a830bbfb37b863270428ba0", null ]
];