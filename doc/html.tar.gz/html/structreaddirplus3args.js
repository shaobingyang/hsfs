var structreaddirplus3args =
[
    [ "dir", "structreaddirplus3args.html#a57d39a7adac84064715c9481d1563d80", null ],
    [ "cookie", "structreaddirplus3args.html#a3320022856a7759e1757a4ab48c9a380", null ],
    [ "cookieverf", "structreaddirplus3args.html#aae8af4f9de9dc26c29fba890972706c0", null ],
    [ "dircount", "structreaddirplus3args.html#ae5e50f1b518998f2c6367896f3eb2f5f", null ],
    [ "maxcount", "structreaddirplus3args.html#a3176a12ef9f455462512ffc7dfc5826e", null ]
];