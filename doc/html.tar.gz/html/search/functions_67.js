var searchData=
[
  ['getfsfile',['getfsfile',['../fstab_8h.html#af0f3e8a6ae95adcdfe7154f7c679ac7c',1,'getfsfile(const char *file):&#160;fstab.c'],['../fstab_8c.html#af0f3e8a6ae95adcdfe7154f7c679ac7c',1,'getfsfile(const char *file):&#160;fstab.c']]],
  ['getfsspec',['getfsspec',['../fstab_8h.html#a32ed78a7baeda8209c4265df7d3fd983',1,'getfsspec(const char *spec):&#160;fstab.c'],['../fstab_8c.html#a32ed78a7baeda8209c4265df7d3fd983',1,'getfsspec(const char *spec):&#160;fstab.c']]],
  ['getmntdevbackward',['getmntdevbackward',['../fstab_8h.html#ae1de283d9c732cc37691f9c4ad8c270b',1,'getmntdevbackward(const char *dev, struct mntentchn *mc):&#160;fstab.c'],['../fstab_8c.html#a513b8b14d346947494d7febe6e24bfc8',1,'getmntdevbackward(const char *name, struct mntentchn *mcprev):&#160;fstab.c']]],
  ['getmntdirbackward',['getmntdirbackward',['../fstab_8h.html#a39f170012e77f0a227d592e2a0b62050',1,'getmntdirbackward(const char *dir, struct mntentchn *mc):&#160;fstab.c'],['../fstab_8c.html#ae81d9d2e297f2f60624dfdfa2a85ca94',1,'getmntdirbackward(const char *name, struct mntentchn *mcprev):&#160;fstab.c']]],
  ['getmntoptfile',['getmntoptfile',['../fstab_8h.html#a443f91293872b29b30f6d00fae76c057',1,'fstab.h']]]
];
