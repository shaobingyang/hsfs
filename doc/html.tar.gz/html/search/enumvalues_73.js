var searchData=
[
  ['set_5fto_5fclient_5ftime',['SET_TO_CLIENT_TIME',['../nfs3_8h.html#a073a77f0e47a0652458d490f531e0c6daaa081929e588b58ae26675e4309e2546',1,'nfs3.h']]],
  ['set_5fto_5fserver_5ftime',['SET_TO_SERVER_TIME',['../nfs3_8h.html#a073a77f0e47a0652458d490f531e0c6daf07a17d65b021da2c7698e6fe4383afc',1,'nfs3.h']]]
];
