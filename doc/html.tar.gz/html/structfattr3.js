var structfattr3 =
[
    [ "type", "structfattr3.html#ada5208793c2297c4f1ead85cf82583f6", null ],
    [ "mode", "structfattr3.html#afb7a04b015af94eb17999218efdb1702", null ],
    [ "nlink", "structfattr3.html#ab93e1c10aa020e15fc6b2546fc204558", null ],
    [ "uid", "structfattr3.html#a8b60f54cc01afb76c0a10520e844698f", null ],
    [ "gid", "structfattr3.html#a3c86d591be7e5f55e5a99e8abe4e0fff", null ],
    [ "size", "structfattr3.html#a20cd5918a5cd8e70a185498398f4e10d", null ],
    [ "used", "structfattr3.html#a9c3d06d4885f0380ebbe940335ebb1d4", null ],
    [ "rdev", "structfattr3.html#ab6429c25111b10914fbf751a98fd85b3", null ],
    [ "fsid", "structfattr3.html#a32998b711fc1cc457ff172c8fd3f2ef5", null ],
    [ "fileid", "structfattr3.html#ae056fb2f84ade36a5247f62d4e04137f", null ],
    [ "atime", "structfattr3.html#a79de0eed682182ca70ae824dfc838250", null ],
    [ "mtime", "structfattr3.html#a503fbef93ba374b0911506dba7207577", null ],
    [ "ctime", "structfattr3.html#afbd0a91fabc2ac162db87464a07a5b9f", null ]
];