var structgetattr3res =
[
    [ "status", "structgetattr3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "attributes", "structgetattr3res.html#a02789be17ef6d486b53ff310a031adfa", null ],
    [ "getattr3res_u", "structgetattr3res.html#abb86e1e25d1143122ace38413bca2629", null ]
];