var searchData=
[
  ['canonicalize',['canonicalize',['../xcommon_8c.html#a3af2cd82f0514540487bcdb54b9a355d',1,'canonicalize(const char *path):&#160;xcommon.c'],['../xcommon_8h.html#a3af2cd82f0514540487bcdb54b9a355d',1,'canonicalize(const char *path):&#160;xcommon.c']]]
];
