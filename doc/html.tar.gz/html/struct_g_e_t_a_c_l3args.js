var struct_g_e_t_a_c_l3args =
[
    [ "fh", "struct_g_e_t_a_c_l3args.html#af9c0376501fe3e2532086f32ce43d6bb", null ],
    [ "mask", "struct_g_e_t_a_c_l3args.html#a190542064263e669514a0ee8f592656c", null ]
];