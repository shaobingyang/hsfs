var structmnt_f_i_l_estruct =
[
    [ "mntent_fp", "structmnt_f_i_l_estruct.html#a7be941ee62987198854aae2c67d677c2", null ],
    [ "mntent_file", "structmnt_f_i_l_estruct.html#a6d6458f8c13fe8c42836e1fc4e0c96c4", null ],
    [ "mntent_lineno", "structmnt_f_i_l_estruct.html#ab36327c3398950a1dc846e2f98059e8f", null ],
    [ "mntent_errs", "structmnt_f_i_l_estruct.html#a7a74a4e59b279a29e28189fa32a88bcd", null ],
    [ "mntent_softerrs", "structmnt_f_i_l_estruct.html#a3d0ebcc33b856699e9b070f55d9261b9", null ]
];