var structpathconf3res =
[
    [ "status", "structpathconf3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "resok", "structpathconf3res.html#ad23a943c3ed25044ec785e2fb904d959", null ],
    [ "resfail", "structpathconf3res.html#ad64b74da9c18659a6db1b926cc5ba052", null ],
    [ "pathconf3res_u", "structpathconf3res.html#adb3312ef699de5c4e753e0d8719fe6a1", null ]
];