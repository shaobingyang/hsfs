var searchData=
[
  ['unlock_5fmtab',['unlock_mtab',['../fstab_8h.html#a7ce6803a0833d2c6161b7abbb2d2b8dc',1,'unlock_mtab(void):&#160;fstab.c'],['../fstab_8c.html#a7ce6803a0833d2c6161b7abbb2d2b8dc',1,'unlock_mtab(void):&#160;fstab.c']]],
  ['update_5fmtab',['update_mtab',['../fstab_8h.html#a20b0a60ab923ca78d6209541972f4f56',1,'update_mtab(const char *special, nfs_mntent_t *with):&#160;fstab.c'],['../fstab_8c.html#aaa6339edb309a742bcae900bf5fdec4b',1,'update_mtab(const char *dir, nfs_mntent_t *instead):&#160;fstab.c']]]
];
