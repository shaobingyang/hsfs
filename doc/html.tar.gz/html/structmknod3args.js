var structmknod3args =
[
    [ "where", "structmknod3args.html#a199e09cf4dc3e9e01c3cf16dd71d7fc1", null ],
    [ "what", "structmknod3args.html#a79fffec3e15099288a57908177202834", null ]
];