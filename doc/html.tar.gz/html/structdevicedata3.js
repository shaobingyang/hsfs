var structdevicedata3 =
[
    [ "dev_attributes", "structdevicedata3.html#a8acdc32bc965af1c66c4eb9e7538faea", null ],
    [ "spec", "structdevicedata3.html#a939c544ae9d2a29d45a612f31c26d690", null ]
];