var structreaddirplus3res =
[
    [ "status", "structreaddirplus3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "resok", "structreaddirplus3res.html#a54c3f19514129493b22d746cc0a55425", null ],
    [ "resfail", "structreaddirplus3res.html#ad64b74da9c18659a6db1b926cc5ba052", null ],
    [ "readdirplus3res_u", "structreaddirplus3res.html#a15fc45f2f636de627f6d443bf18baa4b", null ]
];