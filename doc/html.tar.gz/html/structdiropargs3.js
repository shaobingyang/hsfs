var structdiropargs3 =
[
    [ "dir", "structdiropargs3.html#a57d39a7adac84064715c9481d1563d80", null ],
    [ "name", "structdiropargs3.html#a067b2559647149ee0a8fd423d0d5564d", null ]
];