var structsecattr =
[
    [ "mask", "structsecattr.html#a190542064263e669514a0ee8f592656c", null ],
    [ "aclcnt", "structsecattr.html#a62f445ef989fe785b93923d521eb06c6", null ],
    [ "aclent_len", "structsecattr.html#a72043a9da2c678053479e2d9399fd688", null ],
    [ "aclent_val", "structsecattr.html#abc013b32b548d0d55e78e122e22b84fd", null ],
    [ "aclent", "structsecattr.html#a9d5f7b3749f0851337986ba9e8a8ef9b", null ],
    [ "dfaclcnt", "structsecattr.html#aa751324506f0a859484bc9299459fd2a", null ],
    [ "dfaclent_len", "structsecattr.html#a1ec0f93751205093b48074a212799df4", null ],
    [ "dfaclent_val", "structsecattr.html#a48108af7d67f9f69db9b3f21084687b4", null ],
    [ "dfaclent", "structsecattr.html#a674236482ab57e4a6d7f3320ac5759fd", null ]
];