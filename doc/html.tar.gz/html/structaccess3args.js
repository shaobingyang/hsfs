var structaccess3args =
[
    [ "object", "structaccess3args.html#a8d71a58741a7b7af2f6ae5c069326577", null ],
    [ "access", "structaccess3args.html#a0aec59280f999cd3e73fa696081595a0", null ]
];