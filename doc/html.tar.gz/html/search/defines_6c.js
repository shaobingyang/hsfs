var searchData=
[
  ['localedir',['LOCALEDIR',['../nls_8h.html#ab2cb7816c01560f1bab8b2dbd94be4c8',1,'nls.h']]],
  ['lock_5ftimeout',['LOCK_TIMEOUT',['../fstab_8c.html#ab51d0a82c92884eb8dd5d058a91449af',1,'fstab.c']]],
  ['lstat_5ffollows_5fslashed_5fsymlink',['LSTAT_FOLLOWS_SLASHED_SYMLINK',['../config_8h.html#a34ef112da2cd333b13939ec3dc368af3',1,'config.h']]],
  ['lt_5fobjdir',['LT_OBJDIR',['../config_8h.html#ac2d5925d76379847dd9fc4747b061659',1,'config.h']]]
];
