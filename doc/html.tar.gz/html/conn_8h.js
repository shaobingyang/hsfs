var conn_8h =
[
    [ "clnt_addr_t", "structclnt__addr__t.html", "structclnt__addr__t" ],
    [ "MNT_SENDBUFSIZE", "conn_8h.html#ace920cafe427009472254e953538194c", null ],
    [ "MNT_RECVBUFSIZE", "conn_8h.html#ae94268ab9d3edd8990a1c7dee1593098", null ],
    [ "TIMEOUT", "conn_8h.html#a255c9c5ba3ce2d875fa7f8152fd37579", null ],
    [ "RETRY_TIMEOUT", "conn_8h.html#af831baab34622ec04ab727b732b78ac7", null ]
];