var structfsstat3resok =
[
    [ "obj_attributes", "structfsstat3resok.html#ad21f408dd63203c64171a2c7a1e5d3ea", null ],
    [ "tbytes", "structfsstat3resok.html#a812c70154785e108ce8987ca0d9fc719", null ],
    [ "fbytes", "structfsstat3resok.html#a266131ba5c759192e5e3ab879cb2733f", null ],
    [ "abytes", "structfsstat3resok.html#ac90f3785fefd33fffa6354842053d3f1", null ],
    [ "tfiles", "structfsstat3resok.html#a11aa7e2eacf80e7a4c7a0ee61b6302ea", null ],
    [ "ffiles", "structfsstat3resok.html#a015b13d346bc2b6d76a3f5d422949c89", null ],
    [ "afiles", "structfsstat3resok.html#a7006c2fe0cb186789b8f988729828e21", null ],
    [ "invarsec", "structfsstat3resok.html#ada6f55b119766505be492f3ef663ca14", null ]
];