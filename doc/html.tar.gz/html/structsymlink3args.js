var structsymlink3args =
[
    [ "where", "structsymlink3args.html#a199e09cf4dc3e9e01c3cf16dd71d7fc1", null ],
    [ "symlink", "structsymlink3args.html#a7e308b9f1a167c984c7240225894ed3b", null ]
];