var structreaddirplus3resok =
[
    [ "dir_attributes", "structreaddirplus3resok.html#a6c1ae7519ea651b1784da5df16159fcd", null ],
    [ "cookieverf", "structreaddirplus3resok.html#aae8af4f9de9dc26c29fba890972706c0", null ],
    [ "reply", "structreaddirplus3resok.html#a509e3b37d767798e748b98f654542595", null ]
];