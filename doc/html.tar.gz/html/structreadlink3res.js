var structreadlink3res =
[
    [ "status", "structreadlink3res.html#a512f1f395fe15c6dc05ae466a603a10c", null ],
    [ "resok", "structreadlink3res.html#a2c1f9ff747737e828790ac60ad4a4111", null ],
    [ "resfail", "structreadlink3res.html#ad64b74da9c18659a6db1b926cc5ba052", null ],
    [ "readlink3res_u", "structreadlink3res.html#a474502786fba5fc58dee5f49721056aa", null ]
];