var structpathconf3resok =
[
    [ "obj_attributes", "structpathconf3resok.html#ad21f408dd63203c64171a2c7a1e5d3ea", null ],
    [ "linkmax", "structpathconf3resok.html#a017bcfc35a474d4e681c814c179c250b", null ],
    [ "name_max", "structpathconf3resok.html#a32316acc089dffd5e107ad5b17bf11ac", null ],
    [ "no_trunc", "structpathconf3resok.html#a4f1819fd3571ad15c26c83d9b26277db", null ],
    [ "chown_restricted", "structpathconf3resok.html#ab881dd0482f58396106d167436127e66", null ],
    [ "case_insensitive", "structpathconf3resok.html#ad4042a5cffde07b74cac034955d8c60a", null ],
    [ "case_preserving", "structpathconf3resok.html#aa4d74c69de595aa610258b4c70ecfb1c", null ]
];