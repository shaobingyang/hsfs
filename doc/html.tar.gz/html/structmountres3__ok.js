var structmountres3__ok =
[
    [ "fhandle", "structmountres3__ok.html#a2827c1a2efdb864563eb24febbb4d967", null ],
    [ "auth_flavors_len", "structmountres3__ok.html#a4ee69e0178ce6b9d0b56b3d27cc1c44c", null ],
    [ "auth_flavors_val", "structmountres3__ok.html#a1426c1b9d0cf08eed4e9d0137118b4af", null ],
    [ "auth_flavors", "structmountres3__ok.html#a74e93218cf534349a2602065e5a32e29", null ]
];