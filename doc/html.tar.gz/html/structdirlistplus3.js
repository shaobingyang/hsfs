var structdirlistplus3 =
[
    [ "entries", "structdirlistplus3.html#aac4108046e37cb2860d4c189ec307804", null ],
    [ "eof", "structdirlistplus3.html#a93e57e22ecb79a9a76ba719ca67f1d38", null ]
];