var structspecdata3 =
[
    [ "major", "structspecdata3.html#acb61d7c70bee5c80232a9c1fe1eb1689", null ],
    [ "minor", "structspecdata3.html#a798928c929428eb82a855cf9e8ef39e3", null ]
];