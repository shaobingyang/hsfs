var structfhstatus =
[
    [ "fhs_status", "structfhstatus.html#ae382ef917c044592612e7aed81a0408c", null ],
    [ "fhs_fhandle", "structfhstatus.html#a735da172ec2a101db93b47a236bc25ed", null ],
    [ "fhstatus_u", "structfhstatus.html#a3792facf3994db7f7d6a83a88753516b", null ]
];